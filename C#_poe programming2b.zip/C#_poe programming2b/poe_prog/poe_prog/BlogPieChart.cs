﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace poe_prog
{
    public class BlogPieChart
    {
        public string CategoryName { get; set; }
        public int? PostCount { get; set; }
    }
}
