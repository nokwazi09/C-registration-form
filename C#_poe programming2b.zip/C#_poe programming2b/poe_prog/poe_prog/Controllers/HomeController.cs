﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using poe_prog.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace poe_prog.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public JsonResult GetPieChartJSON()
        {
            List<BlogPieChart> list = new List<BlogPieChart>();
            list.Add(new BlogPieChart { CategoryName = "Module name", PostCount = 10 });
            list.Add(new BlogPieChart { CategoryName = "start date", PostCount = 5 });
            list.Add(new BlogPieChart { CategoryName = "end date ", PostCount = 5 });
            list.Add(new BlogPieChart { CategoryName = "time ", PostCount = 5 });
            return Json(new { JSONList = list });

            {

            }
        }
    }
}
