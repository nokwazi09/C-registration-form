﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace poe_prog.Controllers
{
    public class Class_library
    {
        private static readonly byte[] encryted_byte;
        public static int[] Module_Code = new int[0];
        public static int[] Module_Name = new int[0];
        public static int []Module_credit=new int [0];
        public static int[] hours = new int[0];
        public static DateTime startdate;
        public static DateTime enddate;

        public static string hashpassword(string password)
        {
            SHA1CryptoServiceProvider crypto = new SHA1CryptoServiceProvider();
            byte[] password_byte = Encoding.ASCII.GetBytes(password);
            byte[] encrypted_byte = crypto.ComputeHash(password_byte);
            return Convert.ToBase64String(encryted_byte);
        }
    }
}
