﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using poe_prog.Areas.Identity.Data;
using poe_prog.Data;

[assembly: HostingStartup(typeof(poe_prog.Areas.Identity.IdentityHostingStartup))]
namespace poe_prog.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<poe_progContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("poe_progContextConnection")));

                services.AddDefaultIdentity<poe_progUser>(options => options.SignIn.RequireConfirmedAccount = true)
                    .AddEntityFrameworkStores<poe_progContext>();
            });
        }
    }
}