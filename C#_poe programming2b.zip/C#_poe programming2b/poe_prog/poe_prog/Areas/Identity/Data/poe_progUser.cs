﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace poe_prog.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the poe_progUser class
    public class poe_progUser : IdentityUser
    {
    }
}
